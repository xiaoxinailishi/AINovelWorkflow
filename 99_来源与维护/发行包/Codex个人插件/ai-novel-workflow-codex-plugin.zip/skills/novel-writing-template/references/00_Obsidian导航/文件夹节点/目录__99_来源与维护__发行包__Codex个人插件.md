# 📁 99_来源与维护\发行包\Codex个人插件

- 节点类型：物理文件夹映射
- 实际目录：`99_来源与维护\发行包\Codex个人插件`

- 上级文件夹：发行包

## 本文件夹文档

- ai-novel-workflow-codex-plugin.zip
- README.md
