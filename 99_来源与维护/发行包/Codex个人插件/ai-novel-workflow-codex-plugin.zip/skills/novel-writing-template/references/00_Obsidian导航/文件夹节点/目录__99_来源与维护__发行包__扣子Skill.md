# 📁 99_来源与维护\发行包\扣子Skill

- 节点类型：物理文件夹映射
- 实际目录：`99_来源与维护\发行包\扣子Skill`

- 上级文件夹：发行包

## 本文件夹文档

- novel-writing-template-coze.zip
- README.md
